const bread: string = "everyday bread";

const age : number = 18;

const isMarried : boolean = false;

const stringArray : string[] = ["Micheal,", "Gift", "Miracle"];
const numArray : Array<number> = [1,3,4,5,56,6,];

//tuple 
 const stringTuple : [string, number, boolean] = ["Mack", 2, false];

 enum CardinalPoints{
    EAST,
    WEST,
    NORTH,
    SOUTH
}

 const myLocation :CardinalPoints = CardinalPoints.EAST;

 enum Gender {
    MALE,
    FEMALE,
    AMOEBA
 }

 const bobrisky: Gender = Gender.FEMALE;

 function sayHello( name : string): string {
    return `Hello ${name}`;
 }


 console.log(sayHello("Okoro mmaduka Paulinus"))